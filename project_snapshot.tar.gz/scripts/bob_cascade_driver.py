"""
Bob-side Cascade reconciliation + Toeplitz PA driver for real FABRIC
deployment, with optional SDC fault injection at all three points.
Output filenames are now auto-suffixed with a timestamp + key parameters
to prevent silent overwrites across different sweeps.
"""
import sys
import argparse
import json
import time
import datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
from galois import GF2
from randextract import ToeplitzHashing

from qne.cascade.key import key_from_sifted_json
from qne.cascade import ORIGINAL, Reconciliation
from qne.cascade.classical_session import QFabricClassicalSession
from qne.cascade.fault_injection import SDCFaultInjector
from qne.channel import ClassicalServer


def make_unique_output_path(base_output, toeplitz_prob, hash_prob, reconciliation_prob, seed):
    """Appends a timestamp + the actual fault parameters to the requested
    output filename, so re-running with different parameters (or at a
    different time) never silently overwrites a previous result."""
    base = Path(base_output)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    suffix = f"tp{toeplitz_prob}_hp{hash_prob}_rp{reconciliation_prob}_seed{seed}_{timestamp}"
    return base.parent / f"{base.stem}_{suffix}{base.suffix}"


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--key-json", required=True)
    parser.add_argument("--alice-key-json", required=False, default=None)
    parser.add_argument("--host", default="0.0.0.0")
    parser.add_argument("--port", type=int, default=5200)
    parser.add_argument("--qber", type=float, required=True)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--toeplitz-prob", type=float, default=0.0)
    parser.add_argument("--hash-prob", type=float, default=0.0)
    parser.add_argument("--reconciliation-prob", type=float, default=0.0)
    parser.add_argument("--output", default="results/bob_reconciled.json")
    parser.add_argument("--no-unique-suffix", action="store_true",
                         help="Disable automatic unique filename suffixing (not recommended).")
    args = parser.parse_args()

    if args.no_unique_suffix:
        output_path = args.output
    else:
        output_path = str(make_unique_output_path(
            args.output, args.toeplitz_prob, args.hash_prob, args.reconciliation_prob, args.seed))

    bob_key, _ = key_from_sifted_json(args.key_json, "bob_bits")
    alice_key = None
    if args.alice_key_json:
        alice_key, _ = key_from_sifted_json(args.alice_key_json, "alice_bits")

    t0 = time.time()
    non_convergent = False
    error_msg = None

    injector = SDCFaultInjector(
        toeplitz_matrix_prob=args.toeplitz_prob,
        hash_output_prob=args.hash_prob,
        reconciliation_state_prob=args.reconciliation_prob,
        seed=args.seed + 2,
    )

    server = ClassicalServer(args.host, args.port)
    server.start()
    print(f"Bob: waiting for Alice on {args.host}:{args.port}...")
    channel = server.accept()
    print("Bob: Alice connected, starting reconciliation")

    result = {
        "toeplitz_prob": args.toeplitz_prob, "hash_prob": args.hash_prob,
        "reconciliation_prob": args.reconciliation_prob, "seed": args.seed,
        "output_path": output_path,
    }

    try:
        session = QFabricClassicalSession(channel)
        reconciliation = Reconciliation(
            algorithm=ORIGINAL, classical_session=session,
            noisy_key=bob_key, estimated_bit_error_rate=args.qber, seed=args.seed,
            correct_key=alice_key, fault_injector=injector,
        )
        bob_reconciled = reconciliation.reconcile()
        n_bits = bob_reconciled.get_nr_bits()

        out_len = ToeplitzHashing.calculate_length(
            extractor_type="quantum", input_length=n_bits,
            relative_source_entropy=0.5, error_bound=1e-6,
        )
        ext = ToeplitzHashing(input_length=n_bits, output_length=out_len)
        pa_seed = GF2.Random(ext.seed_length)

        channel.send_message({"type": "pa_seed", "seed": np.array(pa_seed).tolist()})
        ack = channel.recv_message()
        assert ack["type"] == "pa_ack"

        bob_final = injector.toeplitz_extract_with_fault(ext, GF2(bob_reconciled.bits), pa_seed, "bob")
        bob_final = injector.maybe_flip_hash_output_bit(bob_final, "bob")

        result.update({
            "total_corrections": len(reconciliation.corrected_bit_positions),
            "secure_key_length": out_len,
            "bob_final_key": np.array(bob_final).tolist(),
            "bob_reconciled_bits": bob_reconciled.bits.tolist(),  # NEW: save the pre-PA key too
        })
        if alice_key is not None:
            result["remaining_errors_after_reconciliation"] = int(alice_key.nr_bits_different(bob_reconciled))
    except RuntimeError as e:
        non_convergent = True
        error_msg = str(e)
        result.update({"total_corrections": None, "secure_key_length": None, "bob_final_key": None})
    finally:
        channel.close()
        server.close()

    result["non_convergent"] = non_convergent
    result["error"] = error_msg
    result["elapsed_seconds"] = time.time() - t0
    result["faults_fired"] = injector.summary()

    Path(output_path).parent.mkdir(parents=True, exist_ok=True)
    with open(output_path, "w") as f:
        json.dump(result, f)
    print(f"Bob: done. Result written to {output_path}")
    print(json.dumps({k: v for k, v in result.items()
                        if k not in ("bob_final_key", "bob_reconciled_bits")}, indent=2))
