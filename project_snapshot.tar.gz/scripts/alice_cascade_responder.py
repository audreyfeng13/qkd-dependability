"""
Alice-side Cascade reconciliation responder + Toeplitz extraction,
for real FABRIC deployment. Output filenames are auto-suffixed with a
timestamp to prevent silent overwrites across different sweeps.
"""
import sys
import argparse
import json
import datetime
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

import numpy as np
from galois import GF2
from randextract import ToeplitzHashing

from qne.cascade.key import key_from_sifted_json
from qne.channel import ClassicalClient


def make_unique_output_path(base_output, seed):
    base = Path(base_output)
    timestamp = datetime.datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    return base.parent / f"{base.stem}_seed{seed}_{timestamp}{base.suffix}"


def run_alice(alice_key, host, port, output_path, seed, max_requests=2000):
    print(f"Alice: connecting to Bob at {host}:{port}...")
    channel = ClassicalClient.connect(host, port)
    try:
        for i in range(max_requests):
            try:
                msg_peek = channel.recv_message()
            except Exception as e:
                print(f"Alice: channel closed during Cascade phase: {e}")
                return

            if msg_peek["type"] == "cascade_ask_parities":
                from qne.cascade.shuffle import Shuffle, ShuffledKey
                shuffle_cache = {}
                parities = []
                for start, end, iteration_nr, shuffle_seed in msg_peek["blocks"]:
                    if iteration_nr not in shuffle_cache:
                        shuffle_cache[iteration_nr] = Shuffle(alice_key.get_nr_bits(), seed=shuffle_seed)
                    shuffle = shuffle_cache[iteration_nr]
                    shuffled_alice_key = ShuffledKey(alice_key, shuffle)
                    parities.append(shuffled_alice_key.compute_range_parity(start, end))
                channel.send_message({"type": "cascade_parities_result", "parities": parities})

            elif msg_peek["type"] == "pa_seed":
                pa_seed_list = msg_peek["seed"]
                pa_seed = GF2(pa_seed_list)
                n_bits = alice_key.get_nr_bits()
                out_len = ToeplitzHashing.calculate_length(
                    extractor_type="quantum", input_length=n_bits,
                    relative_source_entropy=0.5, error_bound=1e-6,
                )
                ext = ToeplitzHashing(input_length=n_bits, output_length=out_len)
                alice_final = ext.extract(GF2(alice_key.bits), pa_seed)

                Path(output_path).parent.mkdir(parents=True, exist_ok=True)
                with open(output_path, "w") as f:
                    json.dump({
                        "alice_final_key": np.array(alice_final).tolist(),
                        "alice_bits": alice_key.bits.tolist(),
                        "output_path": str(output_path),
                    }, f)
                print(f"Alice: PA complete, final key written to {output_path}")
                channel.send_message({"type": "pa_ack"})
                return
            else:
                print(f"Alice: unexpected message type: {msg_peek['type']}")
                return
    finally:
        channel.close()
    print("Alice: done")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--key-json", required=True)
    parser.add_argument("--bob-host", required=True)
    parser.add_argument("--port", type=int, default=5200)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output", default="results/alice_final_key.json")
    parser.add_argument("--no-unique-suffix", action="store_true")
    args = parser.parse_args()

    output_path = args.output if args.no_unique_suffix else str(make_unique_output_path(args.output, args.seed))

    alice_key, _ = key_from_sifted_json(args.key_json, "alice_bits")
    print(f"Alice: loaded key with {alice_key.get_nr_bits()} bits")
    run_alice(alice_key, args.bob_host, args.port, output_path, args.seed)
