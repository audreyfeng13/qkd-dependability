"""
Finite-key secret key length calculation, combining:
- Tomamichel-Leverrier (2017): overall finite-key security bound
- Tomamichel, Martinez-Mateo, Pacher, Elkouss (2014), Corollary 2:
  finite-size-corrected Cascade leakage estimate
"""
import math
from scipy.stats import norm


def h(x):
    if x <= 0 or x >= 1:
        return 0.0
    return -x * math.log2(x) - (1 - x) * math.log2(1 - x)


def v(x):
    if x <= 0 or x >= 1:
        return 0.0
    return x * (1 - x) * (math.log2(x / (1 - x)))**2


def cascade_leakage(n, Q, epsilon):
    xi = 1 + (1 / math.sqrt(n)) * math.sqrt(v(Q) / h(Q)) * norm.ppf(1 - epsilon)
    return xi * n * h(Q)


def optimal_nu(n, confidence=0.99):
    """Parameter-estimation slack that shrinks with block size, so the
    formula correctly converges to the asymptotic limit as n grows."""
    z = norm.ppf(confidence)
    return z / math.sqrt(n)


def finite_key_output_length(n, Q, eps_pa=1e-10, eps_ec=1e-10, c_bar=0.5):
    """Tomamichel-Leverrier (2017) secret key length, using Corollary 2's
    Cascade leakage as r, and a block-size-dependent nu."""
    nu = optimal_nu(n)
    r = cascade_leakage(n, Q, eps_ec)
    t = math.log2(n)
    term = n * (math.log2(1 / c_bar) - h(Q + nu)) - r - t - 2 * math.log2(1 / (2 * eps_pa))
    return max(1, int(term)), r, t


def asymptotic_key_length(n, Q):
    return int(n * max(0, 1 - 2 * h(Q)))