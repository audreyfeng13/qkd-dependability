"""
Reusable sweep orchestration for SDC fault-injection experiments:
local (Mock-session) sweeps and real-channel (FABRIC node) sweeps.
"""
import json as _json
import pandas as pd
from qne.cascade.sdc_runs import run_sdc_experiment_safe


def run_condition_sweep(alice_key, bob_key, qber, label, n_runs=10, base_seed=42, **fault_kwargs):
    rows = []
    for run in range(n_runs):
        result = run_sdc_experiment_safe(
            alice_key=alice_key, bob_key=bob_key, qber=qber,
            seed=base_seed + run, **fault_kwargs,
        )
        result["condition"] = label
        result["run"] = run
        rows.append(result)
        print(f"  run {run}: non_convergent={result['non_convergent']}, "
              f"keys_match={result.get('keys_match')}")
    return pd.DataFrame(rows)


def summarize_outcomes(df, label):
    non_convergent = df["non_convergent"].sum()
    converged = ~df["non_convergent"]
    matched = df["keys_match"].fillna(False)
    converged_mismatched = (converged & ~matched).sum()
    converged_matched = (converged & matched).sum()
    n = len(df)
    print(f"\n=== {label} (n={n}) ===")
    print(f"  Non-convergent:            {non_convergent}/{n}")
    print(f"  Converged but mismatched:  {converged_mismatched}/{n}")
    print(f"  Converged and matched:     {converged_matched}/{n}")
    return {
        "condition": label, "n": n,
        "non_convergent": non_convergent,
        "converged_mismatched": converged_mismatched,
        "converged_matched": converged_matched,
    }


def run_real_channel_trial(bob, alice, bob_ip, real_qber, run, seed,
                             toeplitz_prob=0.0, hash_prob=0.0, timeout=180):
    bob_output = f"results/bob_realchannel_run_{run}.json"
    alice_output = f"results/alice_realchannel_run_{run}.json"

    bob_thread = bob.execute_thread(
        f"cd ~/qfabric && ~/qfabric/.venv/bin/python3 scripts/bob_cascade_driver.py "
        f"--key-json results/bob_sifted_bits.json --alice-key-json results/alice_sifted_bits.json "
        f"--host {bob_ip} --port 5200 --qber {real_qber} --seed {seed} "
        f"--toeplitz-prob {toeplitz_prob} --hash-prob {hash_prob} "
        f"--output {bob_output}"
    )
    alice_thread = alice.execute_thread(
        f"cd ~/qfabric && ~/qfabric/.venv/bin/python3 scripts/alice_cascade_responder.py "
        f"--key-json results/alice_sifted_bits.json --bob-host {bob_ip} --port 5200 "
        f"--output {alice_output}"
    )

    bob_out = bob_thread.result(timeout=timeout)
    alice_thread.result(timeout=timeout // 2)

    stdout_bob, _ = bob.execute(f"cat ~/qfabric/{bob_output}", quiet=True)
    stdout_alice, _ = alice.execute(f"cat ~/qfabric/{alice_output}", quiet=True)

    try:
        bob_result = _json.loads(stdout_bob)
    except _json.JSONDecodeError:
        bob_result = {"error": "no bob output", "raw_stdout": bob_out[0], "raw_stderr": bob_out[1]}

    try:
        alice_result = _json.loads(stdout_alice)
        alice_final_key = alice_result.get("alice_final_key")
    except _json.JSONDecodeError:
        alice_final_key = None

    bob_final_key = bob_result.get("bob_final_key")
    keys_match = (bob_final_key is not None and alice_final_key is not None
                  and bob_final_key == alice_final_key)

    bob_result["keys_match"] = keys_match
    bob_result.pop("bob_final_key", None)
    bob_result["run"] = run
    bob_result["seed"] = seed
    return bob_result


def run_real_channel_reconciliation_trial(bob, alice, bob_ip, real_qber, run, seed,
                                             reconciliation_prob, timeout=180):
    bob_output = f"results/bob_recon_run_{run}.json"

    bob_thread = bob.execute_thread(
        f"cd ~/qfabric && ~/qfabric/.venv/bin/python3 scripts/bob_cascade_driver.py "
        f"--key-json results/bob_sifted_bits.json --alice-key-json results/alice_sifted_bits.json "
        f"--host {bob_ip} --port 5200 --qber {real_qber} --seed {seed} "
        f"--reconciliation-prob {reconciliation_prob} "
        f"--output {bob_output}"
    )
    alice_thread = alice.execute_thread(
        f"cd ~/qfabric && ~/qfabric/.venv/bin/python3 scripts/alice_cascade_responder.py "
        f"--key-json results/alice_sifted_bits.json --bob-host {bob_ip} --port 5200 "
        f"--output results/alice_recon_run_{run}.json"
    )

    bob_out = bob_thread.result(timeout=timeout)
    try:
        alice_thread.result(timeout=timeout // 2)
    except Exception as e:
        print(f"    (Alice side: {e})")

    stdout, _ = bob.execute(f"cat ~/qfabric/{bob_output}", quiet=True)
    try:
        result = _json.loads(stdout)
        result["non_convergent"] = False
    except _json.JSONDecodeError:
        result = {"non_convergent": True, "error": bob_out[1], "reconciliation_prob": reconciliation_prob}

    result["run"] = run
    result["seed"] = seed
    return result


def collect_key_pairs(deploy, slice_obj, alice, bob, bob_ip, project_dir, n_keys=5,
                        scenario_path="validation/scenarios/fabric_1km.yml"):
    from qne.cascade.key import key_from_sifted_json

    alice_mac = alice.get_interface(network_name="net_alice_switch").get_mac()
    bob_mac = bob.get_interface(network_name="net_switch_bob").get_mac()
    sw_alice_mac = slice_obj.get_node("switch").get_interface(network_name="net_alice_switch").get_mac()

    key_pairs = []
    for i in range(n_keys):
        print(f"\n=== Collecting key pair {i} ===")
        deploy.run_bb84(slice_obj, scenario_path, alice_mac, bob_mac,
                          sw_alice_mac=sw_alice_mac, bob_data_ip=bob_ip)

        stdout, _ = alice.execute("cat ~/qfabric/results/alice_sifted_bits.json", quiet=True)
        alice_path = project_dir / "results" / f"alice_sifted_bits_key{i}.json"
        alice_path.write_text(stdout)

        stdout, _ = bob.execute("cat ~/qfabric/results/bob_sifted_bits.json", quiet=True)
        bob_path = project_dir / "results" / f"bob_sifted_bits_key{i}.json"
        bob_path.write_text(stdout)

        alice_key_i, alice_idx_i = key_from_sifted_json(str(alice_path), "alice_bits")
        bob_key_i, bob_idx_i = key_from_sifted_json(str(bob_path), "bob_bits")
        assert alice_idx_i == bob_idx_i, f"key pair {i}: indices don't match!"

        n_bits_i = alice_key_i.get_nr_bits()
        qber_i = alice_key_i.nr_bits_different(bob_key_i) / n_bits_i
        print(f"  key pair {i}: {n_bits_i} bits, QBER = {qber_i:.4f}")

        key_pairs.append({"index": i, "n_bits": n_bits_i, "qber": qber_i,
                            "alice_path": str(alice_path), "bob_path": str(bob_path)})

        alice.upload_file(str(alice_path), f"qfabric/results/alice_sifted_bits_key{i}.json")
        bob.upload_file(str(alice_path), f"qfabric/results/alice_sifted_bits_key{i}.json")
        bob.upload_file(str(bob_path), f"qfabric/results/bob_sifted_bits_key{i}.json")

    return pd.DataFrame(key_pairs)