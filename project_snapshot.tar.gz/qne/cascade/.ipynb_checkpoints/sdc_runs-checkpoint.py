"""
SDC fault-injection sweep: key agreement, undetected mismatches,
secure key length, runtime overhead -- across the three fault types,
alone and combined. Operates on real, provided Alice/Bob key pairs
(e.g., loaded from FABRIC-collected sifted bits), not synthetic keys.
"""
import time
import numpy as np
import pandas as pd
from galois import GF2
from randextract import ToeplitzHashing
from qne.cascade import Key, ORIGINAL, Reconciliation, MockClassicalSession
from qne.cascade.fault_injection import SDCFaultInjector


def run_sdc_experiment(alice_key, bob_key, qber, seed=42,
                        toeplitz_prob=0.0, hash_prob=0.0, reconciliation_prob=0.0):
    """Run one SDC fault-injection trial on a given Alice/Bob key pair.

    alice_key, bob_key: Key objects (e.g., loaded from real FABRIC-collected
        sifted bits via key_from_sifted_json, or synthetic).
    qber: the estimated/measured bit error rate between alice_key and bob_key,
        passed to Cascade for its block-size calculation.
    """
    t0 = time.time()
    n_bits = alice_key.get_nr_bits()

    injector = SDCFaultInjector(
        toeplitz_matrix_prob=toeplitz_prob,
        hash_output_prob=hash_prob,
        reconciliation_state_prob=reconciliation_prob,
        seed=seed + 2,
    )

    # --- Stage 1: Cascade reconciliation (with possible mid-process fault) ---
    session = MockClassicalSession(correct_key=alice_key)
    reconciliation = Reconciliation(
        algorithm=ORIGINAL, classical_session=session, noisy_key=bob_key,
        estimated_bit_error_rate=qber, seed=seed + 100, fault_injector=injector,
    )
    bob_reconciled = reconciliation.reconcile()

    # This is what the REAL protocol would report -- reflects only errors
    # visible to Cascade's own checking, not any downstream fault.
    qber_after_reconciliation = alice_key.nr_bits_different(bob_reconciled) / n_bits

    # --- Stage 2 + 3: Toeplitz PA (with possible matrix + output faults) ---
    out_len = ToeplitzHashing.calculate_length(
        extractor_type="quantum", input_length=n_bits,
        relative_source_entropy=0.5, error_bound=1e-6,
    )
    ext = ToeplitzHashing(input_length=n_bits, output_length=out_len)
    pa_seed = GF2.Random(ext.seed_length)

    alice_final = injector.toeplitz_extract_with_fault(ext, GF2(alice_key.bits), pa_seed, "alice")
    alice_final = injector.maybe_flip_hash_output_bit(alice_final, "alice")

    bob_final = injector.toeplitz_extract_with_fault(ext, GF2(bob_reconciled.bits), pa_seed, "bob")
    bob_final = injector.maybe_flip_hash_output_bit(bob_final, "bob")

    elapsed = time.time() - t0
    keys_match = np.array_equal(alice_final, bob_final)
    n_diff_bits = int(np.sum(alice_final != bob_final))

    return {
        "toeplitz_prob": toeplitz_prob, "hash_prob": hash_prob,
        "reconciliation_prob": reconciliation_prob,
        "qber_after_reconciliation": qber_after_reconciliation,
        "secure_key_length": out_len,
        "keys_match": keys_match,
        "n_mismatched_bits": n_diff_bits,
        "elapsed_seconds": elapsed,
        "faults_fired": injector.summary(),
    }


def run_sdc_experiment_safe(**kwargs):
    """Wraps run_sdc_experiment, catching non-convergence (RuntimeError from
    Cascade's internal loop caps) as a recorded outcome instead of a crash."""
    try:
        result = run_sdc_experiment(**kwargs)
        result["non_convergent"] = False
        result["error"] = None
        return result
    except RuntimeError as e:
        return {
            "toeplitz_prob": kwargs.get("toeplitz_prob", 0.0),
            "hash_prob": kwargs.get("hash_prob", 0.0),
            "reconciliation_prob": kwargs.get("reconciliation_prob", 0.0),
            "qber_after_reconciliation": None,
            "secure_key_length": None,
            "keys_match": False,
            "n_mismatched_bits": None,
            "elapsed_seconds": None,
            "faults_fired": None,
            "non_convergent": True,
            "error": str(e),
        }